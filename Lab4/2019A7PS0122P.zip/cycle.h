#include "linkedlist.h"

int testCyclic(LinkedList *ll);
LinkedList *reverseList(LinkedList *ll);