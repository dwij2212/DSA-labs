#include <time.h>
#include <sys/time.h>
#include "records.h"
#include "sort.h"

double *testRun(record *arr, int size);
int estimateCutoff(record *arr);