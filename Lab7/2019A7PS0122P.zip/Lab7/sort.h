#include "records.h"

void iterativeQuickSort(record arr[], int l, int h, int S);
void iterativeInsertionSort(record arr[], int size);
void combineSort(record arr[], int n, int S);